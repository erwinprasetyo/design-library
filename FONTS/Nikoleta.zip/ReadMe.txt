This font was downloaded for free from Creative Fabrica (www.creativefabrica.com).

You are not allowed to re-sell or re-distribute this font (even for free). You are welcome to link to the freebies page.

This font is covered by our commercial license: https://www.creativefabrica.com/license/

You can find more work from the designer here: https://www.creativefabrica.com/designer/borisgaric/