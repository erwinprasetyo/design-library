Thank you for downloading the Free Font Bundle from www.creativefabrica.com

View this manual to see how to use this font: https://www.creativefabrica.com/the-ultimate-font-guide/

Thank you